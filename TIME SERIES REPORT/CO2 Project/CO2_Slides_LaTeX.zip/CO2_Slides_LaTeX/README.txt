CO2 Presentation - LaTeX (Beamer) source
Author: Pascal Antwi

slides.tex  - the presentation (17 main slides + 4 backup slides, 16:9, Metropolis theme)
notes.tex   - speaker notes (what to say on each slide)
slides.pdf  - compiled presentation
notes.pdf   - compiled speaker notes
figures/slide/ - vector figures sized for the slides

Overleaf: New Project > Upload Project > select this zip > set main document to slides.tex > Recompile (pdfLaTeX).
Local: pdflatex slides (run twice); pdflatex notes (run twice).
