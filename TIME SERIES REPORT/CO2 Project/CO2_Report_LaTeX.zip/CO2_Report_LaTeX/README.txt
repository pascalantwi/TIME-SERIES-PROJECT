CO2 Report - LaTeX source (Pascal Antwi)

main.tex        - the 5-page report (no figures or tables inside)
links.tex       - the clickable "Figure n" / "Table n" links (each opens the figure/table online)
references.bib  - bibliography (numbered [n], with DOIs/URLs)
main.bbl        - pre-built bibliography
main.pdf        - compiled report
Supplement_Figures_and_Tables.pdf - all 15 figures and 17 tables in one file

The figure/table links open images stored in the public GitHub repository
pascalantwi/time-series-project (folder TIME SERIES REPORT/CO2 Project/linked_results).

Overleaf: New Project > Upload Project > select this zip > Recompile (pdfLaTeX).
Local: pdflatex main && bibtex main && pdflatex main && pdflatex main
