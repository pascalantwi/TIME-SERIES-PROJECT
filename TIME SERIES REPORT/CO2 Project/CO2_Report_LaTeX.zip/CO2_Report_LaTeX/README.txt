CO2 Report - LaTeX source

Files: main.tex (report), references.bib (bibliography), main.bbl (pre-built bibliography), main.pdf (compiled report, 5 pages).

Overleaf: New Project > Upload Project > select this zip > Recompile (pdfLaTeX).
Local: pdflatex main && bibtex main && pdflatex main && pdflatex main

Before submitting, replace "Student Name" in the title block of main.tex.
