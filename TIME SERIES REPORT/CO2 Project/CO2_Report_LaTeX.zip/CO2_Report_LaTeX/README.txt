CO2 Report - LaTeX source (Pascal Antwi)

main.tex        - the report: 5 pages of text, references, then the Appendix
appendix.tex    - Appendix A (15 figures) and Appendix B (17 tables)
references.bib  - bibliography (numbered, with DOIs/URLs)
main.bbl        - pre-built bibliography
figures/, tables/ - appendix figures (vector PDF) and tables
main.pdf        - compiled report (pages 1-5 text, 6-21 appendix)

Every "Figure n" / "Table n" in the text is a link to the appendix; every [n] links to the reference list,
and each reference links to its source online.

Overleaf: New Project > Upload Project > select this zip > Recompile (pdfLaTeX).
Local: pdflatex main && bibtex main && pdflatex main && pdflatex main
